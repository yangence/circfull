## circfull: a tool to detect and quantify full-length circRNA isoforms from circFL-seq 
### https://github.com/yangence/circfull/
